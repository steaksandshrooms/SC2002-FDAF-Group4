package main.java.sg.gov.hdb.bto.control.interfaces;

public interface DataService {
    void loadAllData();
    void saveAllData();
}
